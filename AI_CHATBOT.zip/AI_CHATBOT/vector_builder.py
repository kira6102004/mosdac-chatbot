from pathlib import Path
from langchain_community.document_loaders import TextLoader
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter

# ✅ Full absolute path to data.txt
data_path = Path(__file__).parent / "data.txt"
loader = TextLoader(str(data_path), encoding="utf-8")

raw_documents = loader.load()

text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
documents = text_splitter.split_documents(raw_documents)

embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = FAISS.from_documents(documents, embedding_model)

# Save vector index
vectorstore.save_local("mosdac_vector_index")

print("✅ Vector store created and saved with metadata.")
